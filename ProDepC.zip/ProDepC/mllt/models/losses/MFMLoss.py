import torch
import torch.nn as nn
import torch.nn.functional as F


class MFMLoss(nn.Module):
    def __init__(self,
                 gamma_neg: float = 3.0,
                 gamma_pos: float = 0.0,
                 weight: torch.Tensor = None,  # 类分布权重
                 clip: float = 0.05,
                 eps: float = 1e-8):
        super(MFMLoss, self).__init__()
        self.gamma_neg = gamma_neg
        self.gamma_pos = gamma_pos
        self.clip = clip
        self.eps = eps
        self.weight = weight if weight is not None else torch.tensor(1.0)

        # 禁用梯度计算标志（原实现中的优化）
        self.disable_torch_grad_focal_loss = True

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        prediction: 模型输出概率 [N, C] (经过sigmoid)
        targets: 真实标签 [N, C]
        """

        prediction = torch.sigmoid(logits)
        # 1. 正负样本概率分离
        xs_pos = prediction
        xs_neg = 1 - prediction

        # 2. 负样本裁剪（防止梯度消失）
        if self.clip is not None and self.clip > 0:
            xs_neg = (xs_neg + self.clip).clamp(max=1)

        # 3. 基础交叉熵计算
        los_pos = targets * torch.log(xs_pos.clamp(min=self.eps))
        los_neg = (1 - targets) * torch.log(xs_neg.clamp(min=self.eps))
        loss = los_pos + los_neg

        # 4. 类分布权重调整（解决头尾不平衡）
        loss *= self.weight

        # 5. 多焦点调制核心（论文公式5）
        if self.gamma_neg > 0 or self.gamma_pos > 0:
            if self.disable_torch_grad_focal_loss:
                torch.set_grad_enabled(False)

            # 计算难度权重
            pt0 = xs_pos * targets
            pt1 = xs_neg * (1 - targets)
            pt = pt0 + pt1

            # 解耦正负样本焦点因子
            one_sided_gamma = (
                    (self.gamma_pos) * targets +
                    (self.gamma_neg + self.weight) * (1 - targets)  # 含类权重
            )

            # 应用焦点调制
            one_sided_w = torch.pow(1 - pt, one_sided_gamma)

            if self.disable_torch_grad_focal_loss:
                torch.set_grad_enabled(True)

            loss *= one_sided_w

        return -loss.mean()