import torch
from torch.utils.data import Dataset
from utils.imagelist import *
from utils.pml_data import generate_uniform_cv_candidate_labels
import mmcv
class CustomDataset(Dataset):
    """Dataset.
    """

    def __init__(self, dataset, split, args):
        assert dataset in ["coco-lt", "voc-lt", "voc", "nus-wide"]
        if dataset == 'coco-lt':
            self.data_source = ImageList(root='./data/coco/',
                                        list_file='./data/coco/coco_lt_%s.txt' % split,
                                        label_file='./data/coco/coco_labels.txt',
                                        nb_classes=80,
                                        split=split)
        elif dataset == 'voc-lt':
            self.data_source = ImageList(root='./data/voc/',
                                        list_file='./data/voc/voc_lt_%s.txt' % split,
                                        label_file='./data/voc/voc_labels.txt',
                                        nb_classes=20,
                                        split=split)

        self.targets = self.data_source.labels # one-hot label
        self.categories = self.data_source.categories
        self.fns = self.data_source.fns
        self.ind1 = self.data_source.ind1

        data_dir_prod = args.data_dir
        if not os.path.exists(data_dir_prod):
            os.makedirs(data_dir_prod)

        print('==> Loading local data copy in the partial multi-label setup')
        data_file = "{ds}_{pr}_sd{sd}.npy".format(
            ds=args.dataset,
            pr=args.partial_rate,
            sd=args.seed)

        save_path = os.path.join(data_dir_prod, data_file)
        if not os.path.exists(save_path):
            Partial_Labels = generate_uniform_cv_candidate_labels(self.targets, args.partial_rate)
            data_dict = {
                'partial_labels': Partial_Labels
            }
            save_path = os.path.join(data_dir_prod, data_file)
            with open(save_path, 'wb') as f:
                np.save(f, data_dict)
            print('local data saved at ', save_path)
        else:
            data_dict = np.load(save_path, allow_pickle=True).item()
            Partial_Labels = data_dict['partial_labels']

        partialY = torch.from_numpy(Partial_Labels)
        if torch.sum(partialY * torch.from_numpy(self.targets)) == torch.sum(
                torch.from_numpy(self.targets)):
            print('partialY correctly loaded')
        else:
            print('inconsistent permutation')
        # check partial labels
        print('Average candidate num: ', partialY.squeeze(1).sum(1).mean())

        self.Partial_Labels_index = self.data_source.ind1
        self.Partial_Labels = Partial_Labels

    def __len__(self):
        return self.data_source.get_length()

    def __getitem__(self, idx):
        img, target = self.data_source.get_sample(idx)
        return img, target

def build_dataset1(dataset, split, args):
    assert split in ['train', 'test', 'val']

    assert dataset in ["coco-lt", "voc-lt"]
    if split == 'train':
        dataset = CustomDataset(
        dataset=dataset,
        split=split,
        args=args
        )
    elif split == 'test':
        dataset = CustomDataset(
        dataset=dataset,
        split=split
        )

    return dataset
